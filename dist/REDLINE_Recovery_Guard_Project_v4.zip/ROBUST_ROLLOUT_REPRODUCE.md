# Selective recovery-override study v4

This research archive is not the competition entry. Extract into a new folder.
Windows, Python 3.10+, Node 20+; install the pinned simulator with npm ci.
Frozen input manifests retain some Windows-native paths. Their original
audit tools should be run on Windows; ZIP member names use standard slashes.

    python tools/evaluate_recovery_guard.py --audit
    python tools/audit_robust_history.py
    python tools/verify_release.py
    npm test

Read research/robust-rollout-v4/REPORT.md and PROTOCOL.md. The main audit
recomputes the source/schedule checks, validation eligibility and selected
candidate, paired comparisons and gates. It handles either the predeclared
792-game validation-futility stop or the full 2,760-game study. Sources and
rules remain frozen; no post-hoc tuning or source substitution.

The original 376 v1 games, 792 v2 games and 1,000 retained v3 games are included
for transparency. These earlier attempts failed or stopped and are excluded
from v4 strength estimates. Historical replay diagnostics are development
information only. The separate history audit verifies their retained records.
No original private teammate submissions are included.
