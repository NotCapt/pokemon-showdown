# Frozen diverse league reproducer

This archive preserves the Windows/Python 3.10/Node 24 campaign inputs,
including the original v4.5 team, exact compiled agents, and frozen schedules.
It contains no cached battle outcomes, private teammate originals or secrets.
The paths in the original manifest use Windows separators. Run this archive
on Windows in a separate extracted directory, rather than over a newer release.

Install Python 3.10 and Node 24. In this extracted project directory run:

    npm ci --omit=optional --no-audit --no-fund
    python tools/audit_diverse_league.py --preflight
    python tools/run_diverse_league.py --workers 6
    python tools/audit_diverse_league.py
    python tools/check_league_execution_modes.py
    python tools/summarize_diverse_league.py

The plan schedules 8,856 games. Complete jobs are cached for resume. Use fewer
workers if needed; workers do not change the frozen scoring or schedules.
The execution-mode diagnostic adds 192 games outside the 8,856-game score.
Results are written to research/diverse-league-v1. No competition entry or
external upload is performed. See research/DIVERSE_LEAGUE.md for the protocol.
