# Frozen Monte Carlo rollout experiment

This research package is not the competition submission. Read
research/monte-carlo-v1/REPORT.md for the result and limitations.
Extract into a separate directory. Python 3.10+, Node 20+:

    npm ci
    python tools/audit_monte_carlo.py
    python tools/verify_release.py
    npm test

The audit recomputes 6,048 stored results, their schedules, hashes, ranks,
paired intervals, challenger selection and promotion gates. Frozen model
sources, legal team files and all battle result records are included.
No private original teammate submissions are included. Runtime preflight
evidence predates the battle campaign; do not overwrite frozen inputs.

To rerun the scheduled battles, remove only extracted jobs/ records first:

    python tools/evaluate_monte_carlo.py --run --workers 6

Selection and all model inputs remain frozen; no field tuning is performed.
Scores concern the local test field, not guaranteed tournament performance.
