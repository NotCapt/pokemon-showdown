# Frozen v4.7 follow-up tests

Extract into a separate directory; Python 3.10+, Node 20+:

    npm ci
    python tools/test_v4_7_matchups.py --audit

Read research/v4_7-matchups-v1/REPORT.md and PROTOCOL.md for the results,
methods and limitations. All 2,336 raw game records and their job stamps
are included. Audit checks exact source hashes, teams, seeds, side pairing,
opponent sets, legal execution and native self-play symmetry, then recomputes
the counts, matrices and paired descriptive intervals.

    python tools/test_v4_7_matchups.py --run --workers 6

resumes missing jobs using the frozen plan. To rerun every battle, remove only
the extracted research/v4_7-matchups-v1/jobs directory first. Do not overwrite
the original campaign or tune candidates on these results.
No private original teammate submissions or competition upload is included.
