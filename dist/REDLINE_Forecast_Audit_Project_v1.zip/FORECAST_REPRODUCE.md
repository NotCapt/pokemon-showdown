# Frozen forecast experiments and original v4.6 audit

This is a research reproducer, not the competition submission ZIP.
The recommended submission remains dist/REDLINE_Search_v4_6.zip.
The new recovery, roster and temporal policies failed their release gates.

Extract into a separate directory. Use Python 3.10+ and Node 18+:

    npm ci
    python tools/audit_roster_forecast.py
    python tools/audit_phased_forecast.py
    python tools/audit_submission_readiness.py
    python tools/verify_release.py
    npm test

All 6,048 scheduled battle records, stamps, frozen inputs and aggregate results
are included. Shared control/recovery records are counted only once. The audit
commands recompute schedules, scores, paired intervals and promotion decisions;
they do not run new battles. The readiness audit uses the official options
snapshot checked on 16 October 2026, not a fresh future legality guarantee.

To rerun battles, remove job records only within this extracted project, then:

    python tools/evaluate_roster_forecast.py --run --workers 6
    python tools/evaluate_phased_forecast.py

Immutable manifests reject modified inputs. Original private teammate
submissions and downloaded organizer guides are excluded.
